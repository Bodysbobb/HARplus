# HARplus
 An extension of the HARr package for improved reading of .HAR and .SL4 files.


ACADEMIC CITATION REQUIREMENT:

If this software is used for research, academic work, or published in any scientific or academic context, proper attribution must be given by citing the following paper:

Puangchit, P. (2025). "Title of Your Paper." Journal Name, Volume(Issue), Pages. DOI: 10.xxxx/xxxxx

Failure to provide appropriate citation may constitute a violation of academic ethics and best practices.
